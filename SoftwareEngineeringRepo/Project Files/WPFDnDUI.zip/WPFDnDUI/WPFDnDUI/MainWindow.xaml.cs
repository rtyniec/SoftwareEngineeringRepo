﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFDnDUI
{
    
    public partial class MainWindow : Window
    {
        
        string strName = "";
        string strRace = "";
        string strClass = "";
        string strAlignment = "";

        int intStrength = -1;
        int intDexterity = -1;
        int intConstitution = -1;
        int intIntelligence = -1;
        int intWisdom = -1;
        int intCharisma = -1;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            
            if (txtName.Text.Length == 0)
            {
                MessageBox.Show($"Please enter your name.");
            }
            else if (txtRace.Text.Length == 0)
            {
                MessageBox.Show($"Please enter your race.");
            }
            else if (txtClass.Text.Length == 0)
            {
                MessageBox.Show($"Please enter your class.");
            }
            else if (txtAlignment.Text.Length == 0)
            {
                MessageBox.Show($"Please enter your alignment.");
            }
            else
            {
                strName = txtName.Text;
                strRace = txtRace.Text;
                strClass = txtClass.Text;
                strAlignment = txtAlignment.Text;

                if (txtStrength.Text.Length == 0 || txtDexterity.Text.Length == 0 || txtConstitution.Text.Length == 0 ||
                    txtIntelligence.Text.Length == 0 || txtWisdom.Text.Length == 0 || txtCharisma.Text.Length == 0)
                {
                    MessageBox.Show($"Please enter your ability numbers.");
                }
                else
                {
                    try
                    {
                        intStrength = int.Parse(txtStrength.Text);
                        intDexterity = int.Parse(txtDexterity.Text);
                        intConstitution = int.Parse(txtConstitution.Text);
                        intIntelligence = int.Parse(txtIntelligence.Text);
                        intWisdom = int.Parse(txtWisdom.Text);
                        intCharisma = int.Parse(txtCharisma.Text);

                        MessageBox.Show($"Success!");
                    }
                    catch
                    {
                        MessageBox.Show($"Please enter only numerical digits into the ability fields.");
                    }
                }
            }
        }

        private void BtnLoadCharacter_Click(object sender, RoutedEventArgs e)
        {
            if(strName == "" || strRace == "" || strClass == "" || strAlignment == "" || intStrength == -1 || intDexterity == -1 ||
                intConstitution == -1 || intIntelligence == -1 || intWisdom == -1 || intCharisma == -1)
            {
                MessageBox.Show($"Failed to load character.");
            }
            else
            {
                txtName.Text = strName;
                txtRace.Text = strRace;
                txtClass.Text = strClass;
                txtAlignment.Text = strAlignment;

                txtStrength.Text = intStrength.ToString();
                txtDexterity.Text = intDexterity.ToString();
                txtConstitution.Text = intConstitution.ToString();
                txtIntelligence.Text = intIntelligence.ToString();
                txtWisdom.Text = intWisdom.ToString();
                txtCharisma.Text = intCharisma.ToString();

                MessageBox.Show($"Character loaded!");
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtName.Clear();
            txtRace.Clear();
            txtClass.Clear();
            txtAlignment.Clear();

            txtStrength.Clear();
            txtDexterity.Clear();
            txtConstitution.Clear();
            txtIntelligence.Clear();
            txtWisdom.Clear();
            txtCharisma.Clear();

            MessageBox.Show($"Entries cleared.");
        }
    }
}
