﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Text;

namespace WPFUI.ViewModels
{
    class MainViewModel : Screen
    {

    }
}
