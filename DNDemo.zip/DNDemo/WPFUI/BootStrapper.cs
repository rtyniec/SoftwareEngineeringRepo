﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using System.Windows;
using WPFUI.ViewModels;

namespace WPFUI
{
    public class BootStrapper : BootstrapperBase
    {
        public BootStrapper()
        {
            Initialize(); 
        }

        protected override void OnStartup(object sender, StartupEventArgs e)
        {
            DisplayRootViewFor<MainViewModel>();
        }
    }
}
